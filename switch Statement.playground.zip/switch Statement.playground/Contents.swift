
var score = 1

if score == 0 {
    print("Very bad")
}else if score > 0 && score < 50 {
    print("Bad")
}else if score > 50 && score < 80 {
    print("Good")
}else {
    print("Excellent")
}
//Switch

switch score {
case 0,1:
    print("Very bad")
case 1..<50:
    print("Bad")
case 50..<80:
    print("Good")
default:
print("Excellent")
    
}
//
//optionals
var username :String? //< ? it's mean optional
print(username ?? "default value")
if username == nil {
    print("username required")
}else{
    print("Call api")
}
username = "Ruba"
print(username!)// ! > unrap فك , اذا كنت متاكدة انو المتغير له قيمة + هو يفك النغليف اللي عليه حق الاوبشنال

//another way
if let Name = username {
    print(Name)
}
var q :Int?
var w :Int!
print(q ?? 2 + 5)
print(w + 7)

